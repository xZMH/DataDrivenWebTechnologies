﻿using System.ComponentModel.DataAnnotations;

namespace Lab04Validation.Models
{
    public class LaptopRepair
    {
        [Required (ErrorMessage = "The student id is required")]
        [Display (Name = "Student ID")]
        public string? StudentId { get; set; }

        [Required (ErrorMessage = "The student name is required")]
        [RegularExpression(@"[A-Za-z]\s*[A-Za-z]*$", ErrorMessage ="The name only required a chars")]
        [Display (Name = "Student Name")]
        public string? StudentName {  get; set; }
        [Required (ErrorMessage ="The Major is required")]
        [Display (Name = "Student Major")]
        public MajorTypes? Major {  get; set; }
        [Required(ErrorMessage = "The request Date is required")]
        [Display(Name = "Request Date")]
        public DateTime? RequestDate { get; set; }
        [DataType(DataType.Date, ErrorMessage = "Date format is invalid")]
        [Display (Name = "Repair Date")]
        public DateTime? RepairDate { get; set; }
        [Display (Name = "Repair Cost")]
        [Range(10,100,ErrorMessage = "The {0} must be between {1} and {2}")]
        public int? RepairCost {  get; set; }   
        public string? Repaired {  get; set; }  
    }

    public enum MajorTypes
    {
        CIS = 1, Business = 2 , Application = 3, Engineering = 4
    }
}
